package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@SpringBootApplication
@RestController(value="/app")
@EnableHystrix
@EnableCircuitBreaker
@EnableHystrixDashboard
public class HystrixApplication {
	public static void main(String[] args) {
		SpringApplication.run(HystrixApplication.class, args);
	}
	
	@GetMapping( value="demo1")
	@HystrixCommand(commandKey="default", groupKey="db", fallbackMethod="defaultfallback")
    public Object[] defaultmethod() {
		RestTemplate template = new RestTemplate();
		System.out.println("In defaultmethod  of Application1  ...");
		ResponseEntity<Object[]> respentity = template.getForEntity("http://localhost:8080/", Object[].class);
		return respentity.getBody();
    }
	public Object[]  defaultfallback(){
		System.out.println("In fallback......");
		return new Object[0];
	}
	
}
