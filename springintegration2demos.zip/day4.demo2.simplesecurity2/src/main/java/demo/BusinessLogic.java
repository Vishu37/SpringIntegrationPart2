package demo;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Component;

@Component(value="blogic")
public class BusinessLogic {

	@Secured(value="ROLE_user")
	public void m1(){
		System.out.println("in m1 ....");
	}
	@Secured(value="ROLE_admin")
	public void m2(){
		System.out.println("in m2....");
	}
}
