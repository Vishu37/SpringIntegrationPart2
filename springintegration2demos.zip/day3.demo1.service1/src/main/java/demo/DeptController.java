package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import models.Dept;
import repos.DeptRepository;
@RestController(value="/")
public class DeptController {
	@Autowired
	
	private DeptRepository deptrepo;
	@GetMapping
	public List<Dept> list(){
		System.out.println("list .." + deptrepo.count());
		return deptrepo.findAll();
	}
}
