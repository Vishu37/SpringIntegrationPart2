package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import ch.qos.logback.core.net.SyslogOutputStream;
import models.Dept;
import repos.DeptRepository;

/**
 * @author admin
 *
 */
@SpringBootApplication
@EnableJpaRepositories(basePackages = "repos")
@EntityScan(basePackages = "models")
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public String deptdemo(DeptRepository deptrepo) {
		for (int i = 10; i < 100; i += 10) {
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("Nameof" + i);
			if ((i % 20) == 0)
				d.setLoc("Hyd");
			else
				d.setLoc("Blr");
			deptrepo.save(d);
		}
		Dept d1 = deptrepo.findOne(10);
		System.out.println("d1 = " + d1);
		deptrepo.delete(20);
		Dept d= new Dept(90, "Training","Pnq");
		deptrepo.save(d);
		deptrepo.findAll().forEach(System.out::println);
		return "success";
	}
}
