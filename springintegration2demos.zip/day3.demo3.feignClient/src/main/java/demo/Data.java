package demo;

public class Data {
	private User data;

	@Override
	public String toString() {
		return "Data [data=" + data + "]";
	}

	public User getData() {
		return data;
	}

	public void setData(User data) {
		this.data = data;
	}

	
}