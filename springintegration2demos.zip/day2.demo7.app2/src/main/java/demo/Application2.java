package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController(value="/")
public class Application2 {

	public static void main(String[] args) {
		SpringApplication.run(Application2.class, args);
	}
	@GetMapping
    public String defaultmethod() {
		return "<h1 style='color:blue;'>In defaultmethod  of Application2  ...</h1>";
    }
	@GetMapping(value="/m1")
    public String m1() {
		return "<h1 style='color:blue;'>In m1 of Application2  ...</h1>";
    }
	@GetMapping(value="/m2")
    public String m2() {
		return "<h1 style='color:blue;'>In m2 of Application2  ...</h1>";
    }
	
}
