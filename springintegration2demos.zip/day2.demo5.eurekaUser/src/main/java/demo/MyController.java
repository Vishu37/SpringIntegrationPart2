package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController(value="/")
public class MyController {
	 @GetMapping
	    public String home() {
	//	 ResponseEntity<String> output =template.getForEntity("http://localhost:8092/", String.class);
		 ResponseEntity<String> output =template.getForEntity("http://db-service", String.class);
		 String ret = output.getBody();
		 System.out.println("Server returned output = " + ret);
		  return "<h1>In UserService ..." +ret + "</h1>";
	    }
	 @Autowired
	 private RestTemplate template;
	 
}
