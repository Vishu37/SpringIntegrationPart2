package models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "prodTable")
public class Product {
	@Id
	@GeneratedValue
	@Column(name = "prodidCol")
	private long prodid;
	@Column(name = "prodnameCol", length = 20)
	private String prodname;
	@Column(name = "catColumn", length = 20)
	private String prodcategory;
	@Column(name = "costCol")
	private double cost;
	@Column(name = "odatecol")
	private Date orderDate;
	public long getProdid() {
		return prodid;
	}
	public void setProdid(long prodid) {
		this.prodid = prodid;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	public String getProdcategory() {
		return prodcategory;
	}
	public void setProdcategory(String prodcategory) {
		this.prodcategory = prodcategory;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Product [prodid=" + prodid + ", prodname=" + prodname + ", prodcategory=" + prodcategory + ", cost="
				+ cost + ", orderdate=" + getOrderDate() + "]";
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

}
