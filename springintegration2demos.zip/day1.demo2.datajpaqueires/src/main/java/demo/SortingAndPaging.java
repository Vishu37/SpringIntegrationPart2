package demo;

import java.util.Arrays;
import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import models.Product;
import repos.ProductRepository;
@Configuration
public class SortingAndPaging {
	
	@Bean()
	@Scope( value="prototype")
	public String pagination1(ProductRepository prodrepo) {
	System.out.println("Basic Pagination ... ");
	Scanner scanner = new Scanner(System.in);
	String s ="";
	int start = 0, count = 10;
	do{
		PageRequest req = new PageRequest(start, count);
		prodrepo.findAll(req).forEach(System.out::println);
		System.out.println("Press N to continue... ");
		s = scanner.nextLine();
		start += 1;
	}while(s.equals("N"));
		return "success";
	}
	@Bean()
	@Scope( value="prototype")
	public String pagination2(ProductRepository prodrepo) {
	System.out.println("Basic Pagination ... ");
	Scanner scanner = new Scanner(System.in);
	String s ="";
	
	Page<Product> page;
	int start = 0, count = 50;
	do
	{
		PageRequest req = new PageRequest(start, count);
		page = prodrepo.findAll(req);
		page.forEach(System.out::println);
		System.out.println("Press N to continue... ");
		s = scanner.nextLine();
		start += 1;
	}while(s.equals("N") && page.hasNext());
		return "success";
	}
	@Bean()
	@Scope( value="prototype")
	public String pagination3(ProductRepository prodrepo) {
	System.out.println("Basic Pagination ... ");
	Scanner scanner = new Scanner(System.in);
	String s ="N";
	Pageable pageable =  new PageRequest(0, 50);
	Page<Product> page=prodrepo.findAll(pageable);
	page.forEach(System.out::println);
	while(s.equals("N") && page.hasNext())
	{
		page = prodrepo.findAll(page.nextPageable());
		page.forEach(System.out::println);
		System.out.println("Press N to continue... ");
		s = scanner.nextLine();
		pageable.next();
	}
		return "success";	}
	@Bean()
	@Scope( value="prototype")
	public String prodSort(ProductRepository prodrepo) {
	System.out.println("Basic Sorting ... ");
	Sort sort = new Sort(Sort.Direction.DESC,"prodcategory");
	prodrepo.findAll(sort).forEach(System.out::println);;
		return "success";
	}
	@Bean()
	@Scope( value="prototype")
	public String prodnamecost(ProductRepository prodrepo) {
	System.out.println("Name asc and cost asc Sorting ... ");
	Sort sort = new Sort(Sort.Direction.ASC, Arrays.asList("prodname","cost" ));
	prodrepo.findAll(sort).forEach(System.out::println);;
		return "success";
	}
	@Bean()
	@Scope( value="prototype")
	public String prodnameacostd(ProductRepository prodrepo) {
	System.out.println("Name asc and cost desc Sorting ... ");
	Sort sort = new Sort(Sort.Direction.ASC, "prodname").and(new Sort(Sort.Direction.DESC,"cost"));
	prodrepo.findAll(sort).forEach(System.out::println);;
		return "success";
	}
}
