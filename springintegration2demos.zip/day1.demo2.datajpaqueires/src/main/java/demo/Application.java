package demo;


import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


import models.Product;
import repos.ProductRepository;

/**
 * @author admin
 *
 */
@SpringBootApplication
@EnableJpaRepositories(basePackages = "repos")
@EntityScan(basePackages = "models")
public class Application {

	public static void main(String[] args) {
	ApplicationContext context = 	SpringApplication.run(Application.class, args);
	context.getBean("list3");
	}
	
	@Bean()
	@Scope( value="prototype")
	public String list1(ProductRepository prodrepo) {
		//prodrepo.findByProdcategory("Books").forEach(System.out::println);
		//prodrepo.findByProdname("Fu56").forEach(System.out::println);
	//	prodrepo.findByProdcategoryAndProdname("Books","Bo57").forEach(System.out::println);
	//	prodrepo.findByCostBetween(1000,2000).forEach(System.out::println);
		//prodrepo.findByProdnameStartingWith("Bo4").forEach(System.out::println);
		prodrepo.myquery1("Bo41").forEach(System.out::println);
		return "success";
	}
	@Bean()
	@Scope( value="prototype")
	public String list2(ProductRepository prodrepo) {
		Product p = new Product();
		p.setProdcategory("Books");
		Example<Product> prodexample = Example.of(p);
		prodrepo.findAll(prodexample).forEach(System.out::println);;
		return "success";
	}
	@Bean()
	@Scope( value="prototype")
	public String list3(ProductRepository prodrepo) {
		Product p = new Product();
		p.setProdcategory("Books");
		
		ExampleMatcher matcher = ExampleMatcher.matchingAny();
		
		Example<Product> prodexample = Example.of(p,matcher);
		prodrepo.findAll(prodexample).forEach(System.out::println);
		return "success";
	}
	
	@Bean()
	@Scope( value="prototype")
	public String prodCreate(ProductRepository prodrepo) {
		List<String> categories = Arrays.asList("Furniture","Books","CDs","Cloths");
		for (int i = 1; i < 100; i += 1) {
			Product prod = new Product();
			prod.setProdcategory(categories.get(i % categories.size()));
			prod.setProdname(prod.getProdcategory().substring(0, 2) + i);
			prod.setOrderDate(new java.sql.Date(new Date().getTime()));
			prod.setCost(i * (int)(Math.random()*1000));
			prodrepo.save(prod);	
			
		}
		return "success";
	}
}
