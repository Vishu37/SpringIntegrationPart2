package demo;

import org.springframework.stereotype.Component;

@Component(value="blogic")
public class BusinessLogic {

	public void m1(){
		System.out.println("in m1 ....");
	}
	
	public void m2(){
		System.out.println("in m2....");
	}
}
