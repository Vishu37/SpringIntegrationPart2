package day2.demo4.eurekaDBService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class MyController {

	/*@Autowired
    private DiscoveryClient discoveryClient;

    @RequestMapping("/service-instances/{applicationName}")
    public List<ServiceInstance> serviceInstancesByApplicationName(
            @PathVariable String applicationName) {
        return this.discoveryClient.getInstances(applicationName);
    }*/
	
	@GetMapping(value="/hello")
	public String hello(){
		return "User Hello World";
	}
	
	@Autowired
	private RestTemplate template;
	
	@GetMapping(value="/dbSerRep")
	public String home(){
	//	ResponseEntity<String> op = template.getForEntity("http://localhost:8092/hello", String.class);
		ResponseEntity<String> op = template.getForEntity("http://db-service/hello", String.class);
		String rep = op.getBody();
		System.out.println("Server return "+rep);
		return rep;
	}
	
	
}
