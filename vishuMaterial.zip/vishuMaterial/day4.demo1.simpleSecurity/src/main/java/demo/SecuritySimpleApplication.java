package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;

/*@Configuration
@ComponentScan()*/
public class SecuritySimpleApplication {

	public static void main(String[] args) {
	//	ApplicationContext context = new AnnotationConfigApplicationContext(SecuritySimpleApplication.class);
		ApplicationContext context = new ClassPathXmlApplicationContext("demo1.xml");
		BusinessLogic logic = context.getBean("blogic",BusinessLogic.class);
		
		SecurityContext scimpl = new SecurityContextImpl();
		Authentication authentication = new  UsernamePasswordAuthenticationToken("user6","pass6");
		scimpl.setAuthentication(authentication);
		SecurityContextHolder.setContext(scimpl);
		
		try {
			logic.m1();
			
		} catch (Exception e) {
			System.out.println("Problem calling m1 " + e);
		}
		try {
			logic.m2();
		} catch (Exception e) {
			System.out.println("Problem calling m2 " + e);
		}
	}

}
