package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ImportResource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;

@SpringBootApplication
@ImportResource("classpath:demo1.xml")
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(Application.class, args);
		
		SecurityContext sc = new SecurityContextImpl();
		
		Authentication auth = new UsernamePasswordAuthenticationToken("user3", "pass3");
		sc.setAuthentication(auth);
		
		SecurityContextHolder.setContext(sc);
				
		BusinessLogic logic = context.getBean("blogic",BusinessLogic.class);
				
		try {
			logic.m1();
		} catch (Exception e) {
			System.out.println("In M1 catch block");
			e.printStackTrace();
		}
		try {
			logic.m2();
		} catch (Exception e) {
			System.out.println("In M2 catch block");
			e.printStackTrace();
		}
	}
}
