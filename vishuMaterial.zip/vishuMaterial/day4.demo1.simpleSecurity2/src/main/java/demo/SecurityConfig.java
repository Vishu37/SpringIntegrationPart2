package demo;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

@Configuration
@EnableGlobalMethodSecurity(securedEnabled=true,prePostEnabled=true)
public class SecurityConfig {
	@Autowired
	private DataSource dataSource;

	/*@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth
			.jdbcAuthentication()
				.dataSource(dataSource)
				.withDefaultSchema()
				.withUser("user7").password("pass7").roles("user").and()
				.withUser("user8").password("pass8").roles("admin").and()
				.withUser("user9").password("pass9").roles("user","admin");
	}*/
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth
			.inMemoryAuthentication()
			.withUser("user7").password("pass7").roles("user").and()
			.withUser("user8").password("pass8").roles("admin").and()
			.withUser("user9").password("pass9").roles("user","admin");
	}
	
	@Bean
	public DataSource getdataSource(){
		return new DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/","sa", "" );
	}
	
}
