package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class app1Application {

	public static void main(String[] args) {
		SpringApplication.run(app1Application.class, args);
	}
	
	@GetMapping(value="/")
	public String m(){
		return "In App1 default";
	}
	
	@GetMapping(value="/m1")
	public String m1(){
		return "In App1 m1";
	}
	
	@GetMapping(value="/m2")
	public String m2(){
		return "In App1 m2";
	}

}
