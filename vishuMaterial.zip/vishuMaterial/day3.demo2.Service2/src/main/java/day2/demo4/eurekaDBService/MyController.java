package day2.demo4.eurekaDBService;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@RestController
public class MyController {

	@GetMapping(value="/hello")
	public String hello(){
		return "User Hello World";
	}
	
	@Autowired
	private RestTemplate template;
	
	@GetMapping(value="/dbSerRep")
	@HystrixCommand(commandKey="default",groupKey="db",fallbackMethod="defaultFallBack")
	public String home(){
		
	//	ResponseEntity<String> op = template.getForEntity("http://localhost:8092/hello", String.class);
		ResponseEntity<String> op = template.getForEntity("http://localhost:8080/dept", String.class);
		String rep = op.getBody();
		System.out.println("Server return "+rep);
		return rep;
	}
	
	@GetMapping(value="/err")
	@HystrixCommand(commandKey="default1",groupKey="err",fallbackMethod="defaultFallBack1")
	public String error() throws Exception{
		System.out.println("In error method");
	throw new Exception();
	}
	
	public String defaultFallBack() {
		System.out.println("In defaultFallBack method");
		return "Error in service so defaultFallBack called";
	}
	
	public String defaultFallBack1(){
		System.out.println("In error fallback method");
		return "Error in service so error defaultFallBack called";
	}
}
