package demo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import models.Product;
import repos.ProdRepository;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "repos")
@EntityScan(basePackages = "models")
public class Application {

	public static void main(String[] args) {
		ApplicationContext acx = SpringApplication.run(Application.class, args);
		// acx.getBean("prodCreate");
	}

	//@Bean
	public String prodDSLQuetires(ProdRepository prodRepo) {
		System.out.println("Basic DSL Queries ..........");
		
		prodRepo.findByProdName("CL 91").forEach(System.out::println);
		prodRepo.findByCostBetween(100, 200).forEach(System.out::println);
		prodRepo.myquery("CL 95").forEach(System.out::println);
		return "success";
	}
	
	//@Bean
	public String prodSort(ProdRepository prodRepo) {
		System.out.println("Basic Sorting ..........");
		Sort sort = new Sort(Sort.Direction.ASC, "prodCategory");
		prodRepo.findAll(sort).forEach(System.out::println);
		return "success";
	}

	//@Bean
	public String prodNameCost(ProdRepository prodRepo) {
		System.out.println("Basic prodNameCost ..........");
		Sort sort = new Sort(Sort.Direction.ASC, Arrays.asList("prodName", "cost"));
		prodRepo.findAll(sort).forEach(System.out::println);
		return "success";
	}
	
	@Bean
	public String list3(ProdRepository prodRepo){
		System.out.println("Basic list3 ..........");
		Product p = new Product();
		p.setProdCategory("Books");
		
		ExampleMatcher matcher = ExampleMatcher.matchingAll();
		Example<Product> Prodexam = Example.of(p,matcher);
		prodRepo.findAll(Prodexam).forEach(System.out::println);
		
		
		/*Product p = new Product();
		p.setProdCategory("Books");
		
		ExampleMatcher matcher = ExampleMatcher.matchingAll();
		Example<Product> Prodexam = Example.of(p,matcher);
		prodRepo.findAll(Prodexam).forEach(System.out::println);*/
		
		return "";
	}

/*	@Bean
	public String prodpagenation(ProdRepository prodRepo) {
		System.out.println("Basic prodpagenation ------------------");
		Scanner sc = new Scanner(System.in);
		int start = 0;
		int count = 50;
		String s = "";
		do {
			PageRequest pr = new PageRequest(start, count);
			prodRepo.findAll(pr).forEach(System.out::println);
			System.out.println("Press N for continue .....");
			start += 10; 
			s = sc.nextLine();
			
		} while (s.equalsIgnoreCase("N"));
		return "success";
	}*/
	
	
	//@Bean
	public String prodpagenationWithPageObj(ProdRepository prodRepo) {
		System.out.println("Basic prodpagenation ------------------");
		Scanner sc = new Scanner(System.in);
		String s = "n";
		PageRequest pr = new PageRequest(0, 10);
		Page<Product> page = prodRepo.findAll(pr);
		while(s.equals("n") && page.hasNext()){
			page.forEach(System.out::println);
			System.out.println("Press N for continue .....");
			s = sc.nextLine();
		} 
		return "success";
	}

	@Bean
	@Scope(value = "prototype")
	public String prodCreate(ProdRepository prodRepo) {
		List<String> categories = Arrays.asList("Furniture", "Books", "CDs", "Cloths");
		for (int i = 1; i < 100; i++) {
			Product p = new Product();
			p.setProdCategory(categories.get(i % categories.size()));
			p.setProdName(p.getProdCategory().substring(0, 2).toUpperCase() + " " + i);
			p.setBdate(new java.sql.Date(new Date().getTime()));
			p.setCost(i * Math.random() * 1000);
			prodRepo.save(p);

		}
		return "sucess";

	}
}
