package models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name="Prod_Table")
public class Product {
	@Id
	@GeneratedValue
	@Column(name="Prod_Id")
	Long prodId;
	@Column(name="Prod_Name", length=20)
	String prodName;
	@Column(name="Prod_Category", length=50)
	String prodCategory;
	@Column(name="Prod_Cost")
	double cost;
	@Column(name="Prod_Date")
	Date bdate;
	public long getProdid() {
		return prodId;
	}
	public void setProdid(long prodid) {
		this.prodId = prodid;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdCategory() {
		return prodCategory;
	}
	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public Date getBdate() {
		return bdate;
	}
	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodName=" + prodName + ", prodCategory=" + prodCategory + ", cost="
				+ cost + ", bdate=" + bdate + "]";
	}
	
	

}
