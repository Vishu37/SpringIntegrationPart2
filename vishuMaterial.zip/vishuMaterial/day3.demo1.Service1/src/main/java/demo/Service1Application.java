package demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import models.Dept;
import repos.DeptRepository;

/**
 * @author admin
 *
 */
@SpringBootApplication
@EnableJpaRepositories(basePackages="repos")
@EntityScan(basePackages="models")
@RestController
public class Service1Application {

	public static void main(String[] args) {
		SpringApplication.run(Service1Application.class, args);
	}
	@Autowired
	private DeptRepository deptrepo;
	
	@GetMapping(value="/dept")
	public List<Dept> deptdemo(){
		System.out.println("Inside dept");
		for (int i = 10; i < 100; i+=10) {
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("D Name"+i);
			if((i%20)==0){
				d.setLoc("Hyd");
			}else 
				d.setLoc("Blr");
			deptrepo.save(d);
			
		}
		deptrepo.findAll().forEach(System.out::println);
		List<Dept> acx = (List<Dept>) deptrepo.findAll();
		return acx;
		
	}
	
	@GetMapping(value="/")
	public String m(){
		return "In Service1 default";
	}
	
	
	
}
