package demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.endpoint.RefreshEndpoint;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
@RequestMapping(value="/")
public class DisplayProp {
	@Value(value="${message: myDefaultHello}")
	private String message;
	RefreshEndpoint refreshEndpoint;
	
	@GetMapping(value="/m")
	public String disp(){
		return message;
	}

	@PostMapping(value="/test/refresh")
	public String[] refresh(){
		System.out.println("Refresh invoked ........ ");
		return refreshEndpoint.refresh();
	}
}
