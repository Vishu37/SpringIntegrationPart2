package day3.day3.demo3.feignDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@EnableFeignClients
public class Application {
	
	String userAgent = "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36";

	public static void main(String[] args) {
		ApplicationContext ac = SpringApplication.run(Application.class, args);
		String value = ac.getBean("userBean1",String.class);
		System.out.println("Value "+value);
		
	}
	@Autowired
	private ReqResClient res;
	
	@Bean
	public String userBean(){
		User u = new User();
		u.setName("morpheus");
		u.setJob("leader");
		String abc = res.update(userAgent,u);
		return abc;
		
	}
	
	@Bean
	public String userBean1(){
	String abc = res.update1(userAgent);
		return abc;
		
	}
}
