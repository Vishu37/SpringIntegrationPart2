package day3.day3.demo3.feignDemo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@FeignClient(name = "client",url="https://reqres.in")
public interface ReqResClient {
    
	//0@RequestMapping(method=RequestMethod.POST, value = "/api/users", consumes="application/json", headers="user-agent: Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36")
	@RequestMapping(method=RequestMethod.POST, value = "/api/users", consumes="application/json")
	String update(@RequestHeader(value="User-Agent") String userAgent , User user);
	
	@RequestMapping(method=RequestMethod.GET, value = "/api/users/2", consumes="application/json")
	String update1(@RequestHeader(value="User-Agent") String userAgent);
}