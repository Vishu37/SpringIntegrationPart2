package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SpringBootApplication
@RestController
@EnableAutoConfiguration
public class app1Application {

	public static void main(String[] args) {
		SpringApplication.run(app1Application.class, args);
	}
	
	@GetMapping(value="/")
	public String m(){
		return " <h1>In default </h1>"
				+ "<h1><a href='my/m1'>Link to M1</a></h1>"
				+ "<h1><a href='my/m2'>Link to M2</a></h1>"
				+ "<h1><a href='my/user'>Link to User</a></h1>";
	}
	
	@Controller
	public static class LoginErrors {

		@RequestMapping("/my/login")
		public String dashboard() {
			return "redirect:/#/";
		}

	}

	@Component
	@EnableOAuth2Sso
	public static class LoginConfigurer extends WebSecurityConfigurerAdapter {

		@Override
		public void configure(HttpSecurity http) throws Exception {
			http.antMatcher("/my/**").authorizeRequests().anyRequest()
					.authenticated().and()
					.logout().logoutUrl("/my/logout").permitAll()
					.logoutSuccessUrl("/");
		}
		
		/*@Override
		public void configure(HttpSecurity http) throws Exception {
			http.antMatcher("/my/**").authorizeRequests().anyRequest()
					.authenticated().and().csrf()
					.csrfTokenRepository(csrfTokenRepository()).and()
					.addFilterAfter(csrfHeaderFilter(), CsrfFilter.class)
					.logout().logoutUrl("/my/logout").permitAll()
					.logoutSuccessUrl("/");
		}*/

/*		private Filter csrfHeaderFilter() {
			return new OncePerRequestFilter() {
				@Override
				protected void doFilterInternal(HttpServletRequest request,
						HttpServletResponse response, FilterChain filterChain)
						throws ServletException, IOException {
					CsrfToken csrf = (CsrfToken) request
							.getAttribute(CsrfToken.class.getName());
					if (csrf != null) {
						Cookie cookie = new Cookie("XSRF-TOKEN",
								csrf.getToken());
						cookie.setPath("/");
						response.addCookie(cookie);
					}
					filterChain.doFilter(request, response);
				}
			};
		}

		private CsrfTokenRepository csrfTokenRepository() {
			HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
			repository.setHeaderName("X-XSRF-TOKEN");
			return repository;
		}*/
	}
	
	

}
