package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class app2Application {

	public static void main(String[] args) {
		SpringApplication.run(app2Application.class, args);
	}
	
	@GetMapping(value="/")
	public String m(){
		return "In App2 default";
	}
	
	@GetMapping(value="/m1")
	public String m1(){
		return "In App2 m1";
	}
	
	@GetMapping(value="/m2")
	public String m2(){
		return "In App2 m2";
	}

}
